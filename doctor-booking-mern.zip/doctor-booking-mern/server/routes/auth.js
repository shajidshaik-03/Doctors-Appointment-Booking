import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { User, Doctor } from "../models/index.js";
import { auth } from "../middleware/auth.js";
const r = Router();
const token = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: "7d" });
const pub = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });
r.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password || password.length < 6) return res.status(400).json({ message: "Email and 6+ char password required" });
  if (await User.findOne({ email })) return res.status(409).json({ message: "Email already registered" });
  const doc = await Doctor.findOne({ email: email.toLowerCase(), user: null });
  const role = (await User.countDocuments()) === 0 ? "admin" : doc ? "doctor" : "patient";
  const u = await User.create({ name, email, password: await bcrypt.hash(password, 10), role });
  if (doc) { doc.user = u._id; await doc.save(); }
  res.status(201).json({ token: token(u), user: pub(u) });
});
r.post("/login", async (req, res) => {
  const u = await User.findOne({ email: req.body.email?.toLowerCase() });
  if (!u || !(await bcrypt.compare(req.body.password || "", u.password))) return res.status(401).json({ message: "Invalid credentials" });
  res.json({ token: token(u), user: pub(u) });
});
r.get("/me", auth, (req, res) => res.json(pub(req.user)));
export default r;
