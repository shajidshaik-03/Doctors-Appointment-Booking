import { Router } from "express";
import { Doctor, Appointment } from "../models/index.js";
import { auth, allow } from "../middleware/auth.js";
const r = Router();
r.get("/", async (q, s) => {
  const f = {};
  if (q.query.department) f.department = q.query.department;
  if (q.query.q) f.$or = [{ name: new RegExp(q.query.q, "i") }, { specialization: new RegExp(q.query.q, "i") }];
  s.json(await Doctor.find(f).populate("department", "name").sort("name"));
});
r.get("/:id", async (q, s) => { const d = await Doctor.findById(q.params.id).populate("department", "name"); d ? s.json(d) : s.status(404).json({ message: "Not found" }); });
r.get("/:id/booked", async (q, s) => s.json((await Appointment.find({ doctor: q.params.id, date: q.query.date, status: { $ne: "cancelled" } })).map((a) => a.time)));
r.post("/", auth, allow("admin"), async (q, s) => s.status(201).json(await Doctor.create(q.body)));
r.put("/:id", auth, allow("admin"), async (q, s) => s.json(await Doctor.findByIdAndUpdate(q.params.id, q.body, { new: true })));
r.delete("/:id", auth, allow("admin"), async (q, s) => { await Doctor.findByIdAndDelete(q.params.id); await Appointment.deleteMany({ doctor: q.params.id }); s.status(204).end(); });
export default r;
