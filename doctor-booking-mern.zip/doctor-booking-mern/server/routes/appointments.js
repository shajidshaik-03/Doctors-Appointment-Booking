import { Router } from "express";
import { Appointment, Doctor } from "../models/index.js";
import { auth, allow } from "../middleware/auth.js";
const r = Router();
r.use(auth);
const scope = async (u) => u.role === "admin" ? {} : u.role === "doctor" ? { doctor: (await Doctor.findOne({ user: u._id }))?._id } : { patient: u._id };
r.get("/", async (q, s) => s.json(await Appointment.find(await scope(q.user)).populate("doctor", "name specialization").populate("patient", "name email").sort("date time")));
r.post("/", allow("patient"), async (q, s) => {
  const { doctor, date, time, reason } = q.body;
  const d = await Doctor.findById(doctor);
  if (!d) return s.status(404).json({ message: "Doctor not found" });
  if (!d.availableDays.includes(new Date(date + "T00:00").getDay())) return s.status(400).json({ message: "Doctor not available that day" });
  try { s.status(201).json(await Appointment.create({ patient: q.user._id, doctor, date, time, reason })); }
  catch (e) { s.status(e.code === 11000 ? 409 : 400).json({ message: e.code === 11000 ? "Slot already booked" : e.message }); }
});
r.put("/:id/status", async (q, s) => {
  const a = await Appointment.findOne({ _id: q.params.id, ...(await scope(q.user)) });
  if (!a) return s.status(404).json({ message: "Not found" });
  if (q.user.role === "patient" && q.body.status !== "cancelled") return s.status(403).json({ message: "Patients can only cancel" });
  a.status = q.body.status; await a.save(); s.json(a);
});
r.delete("/:id", allow("admin"), async (q, s) => { await Appointment.findByIdAndDelete(q.params.id); s.status(204).end(); });
export default r;
