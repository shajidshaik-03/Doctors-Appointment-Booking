import { Router } from "express";
import { Department } from "../models/index.js";
import { auth, allow } from "../middleware/auth.js";
const r = Router();
r.get("/", async (_q, s) => s.json(await Department.find().sort("name")));
r.post("/", auth, allow("admin"), async (q, s) => s.status(201).json(await Department.create(q.body)));
r.put("/:id", auth, allow("admin"), async (q, s) => s.json(await Department.findByIdAndUpdate(q.params.id, q.body, { new: true })));
r.delete("/:id", auth, allow("admin"), async (q, s) => { await Department.findByIdAndDelete(q.params.id); s.status(204).end(); });
export default r;
