import mongoose from "mongoose";
const { Schema, model } = mongoose;
export const User = model("User", new Schema({
  name: String, email: { type: String, unique: true, lowercase: true }, password: String,
  role: { type: String, enum: ["admin", "doctor", "patient"], default: "patient" },
}, { timestamps: true }));
export const Department = model("Department", new Schema({ name: { type: String, unique: true, required: true }, description: String }));
export const Doctor = model("Doctor", new Schema({
  name: { type: String, required: true }, email: String, user: { type: Schema.Types.ObjectId, ref: "User" },
  department: { type: Schema.Types.ObjectId, ref: "Department" }, specialization: String,
  experienceYears: Number, fee: Number, bio: String,
  availableDays: { type: [Number], default: [1, 2, 3, 4, 5] }, startHour: { type: Number, default: 9 }, endHour: { type: Number, default: 17 },
}, { timestamps: true }));
const ap = new Schema({
  patient: { type: Schema.Types.ObjectId, ref: "User", required: true },
  doctor: { type: Schema.Types.ObjectId, ref: "Doctor", required: true },
  date: { type: String, required: true }, time: { type: String, required: true }, reason: String,
  status: { type: String, enum: ["pending", "confirmed", "completed", "cancelled"], default: "pending" },
}, { timestamps: true });
ap.index({ doctor: 1, date: 1, time: 1 }, { unique: true, partialFilterExpression: { status: { $in: ["pending", "confirmed", "completed"] } } });
export const Appointment = model("Appointment", ap);
