import jwt from "jsonwebtoken";
import { User } from "../models/index.js";
export const auth = async (req, res, next) => {
  try {
    const t = req.headers.authorization?.split(" ")[1];
    const { id } = jwt.verify(t, process.env.JWT_SECRET);
    req.user = await User.findById(id).select("-password");
    if (!req.user) throw 0;
    next();
  } catch { res.status(401).json({ message: "Unauthorized" }); }
};
export const allow = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ message: "Forbidden" });
