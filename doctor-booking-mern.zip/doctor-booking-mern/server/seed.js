import "dotenv/config";
import mongoose from "mongoose";
import { Department, Doctor } from "./models/index.js";
await mongoose.connect(process.env.MONGO_URI);
await Department.deleteMany(); await Doctor.deleteMany();
const names = ["Cardiology", "Dermatology", "Orthopedics", "Pediatrics", "Neurology", "General Medicine"];
const d = Object.fromEntries((await Department.insertMany(names.map((name) => ({ name })))).map((x) => [x.name, x._id]));
await Doctor.insertMany([
  { name: "Dr. Ananya Rao", email: "ananya.rao@clinic.test", department: d.Cardiology, specialization: "Interventional Cardiologist", experienceYears: 14, fee: 900, startHour: 9, endHour: 15 },
  { name: "Dr. Priya Nair", email: "priya.nair@clinic.test", department: d.Dermatology, specialization: "Cosmetic Dermatologist", experienceYears: 7, fee: 600, availableDays: [2, 4, 6] },
  { name: "Dr. Arjun Singh", email: "arjun.singh@clinic.test", department: d.Orthopedics, specialization: "Joint Replacement Surgeon", experienceYears: 18, fee: 1000 },
  { name: "Dr. Meera Iyer", email: "meera.iyer@clinic.test", department: d.Pediatrics, specialization: "Pediatrician", experienceYears: 11, fee: 500 },
  { name: "Dr. Rahul Verma", email: "rahul.verma@clinic.test", department: d.Neurology, specialization: "Neurologist", experienceYears: 12, fee: 950, availableDays: [2, 3, 4] },
  { name: "Dr. Sneha Kapoor", email: "sneha.kapoor@clinic.test", department: d["General Medicine"], specialization: "General Physician", experienceYears: 6, fee: 400 },
]);
console.log("Seeded"); process.exit(0);
