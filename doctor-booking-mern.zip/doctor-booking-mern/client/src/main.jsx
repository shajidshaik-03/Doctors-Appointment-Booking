import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Link, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./AuthContext";
import Home from "./pages/Home";
import Doctor from "./pages/Doctor";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
function Nav() {
  const { user, logout } = useAuth();
  return <nav><b>🩺 CareSlot</b><Link to="/">Find doctors</Link>{user ? <><Link to="/dashboard">Dashboard ({user.role})</Link><button className="ghost" onClick={logout}>Sign out</button></> : <Link to="/login">Sign in</Link>}</nav>;
}
const Private = ({ children }) => (useAuth().user || localStorage.getItem("token") ? children : <Navigate to="/login" />);
ReactDOM.createRoot(document.getElementById("root")).render(
  <AuthProvider><BrowserRouter><Nav /><Routes>
    <Route path="/" element={<Home />} /><Route path="/doctors/:id" element={<Doctor />} />
    <Route path="/login" element={<Login />} /><Route path="/dashboard" element={<Private><Dashboard /></Private>} />
  </Routes></BrowserRouter></AuthProvider>);
