import { createContext, useContext, useEffect, useState } from "react";
import api from "./api";
const Ctx = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  useEffect(() => { if (localStorage.getItem("token")) api.get("/auth/me").then((r) => setUser(r.data)).catch(() => localStorage.removeItem("token")); }, []);
  const login = (data) => { localStorage.setItem("token", data.token); setUser(data.user); };
  const logout = () => { localStorage.removeItem("token"); setUser(null); };
  return <Ctx.Provider value={{ user, login, logout }}>{children}</Ctx.Provider>;
}
export const useAuth = () => useContext(Ctx);
