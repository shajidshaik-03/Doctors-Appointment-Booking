import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { DAYS } from "../api";
export default function Home() {
  const [q, setQ] = useState(""); const [dept, setDept] = useState("");
  const [depts, setDepts] = useState([]); const [docs, setDocs] = useState([]);
  useEffect(() => { api.get("/departments").then((r) => setDepts(r.data)); }, []);
  useEffect(() => { api.get("/doctors", { params: { q, department: dept || undefined } }).then((r) => setDocs(r.data)); }, [q, dept]);
  return <div className="wrap"><h1>Find a doctor</h1>
    <input placeholder="Search name or specialization" value={q} onChange={(e) => setQ(e.target.value)} />
    <select value={dept} onChange={(e) => setDept(e.target.value)}><option value="">All departments</option>{depts.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select>
    <div className="grid">{docs.map((d) => <Link key={d._id} to={`/doctors/${d._id}`} className="card"><h3>{d.name}</h3><p>{d.specialization} · {d.department?.name}</p><small>₹{d.fee} · {d.availableDays.map((n) => DAYS[n]).join(", ")}</small></Link>)}</div></div>;
}
