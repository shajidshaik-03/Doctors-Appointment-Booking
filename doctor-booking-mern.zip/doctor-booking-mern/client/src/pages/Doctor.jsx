import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api, { DAYS } from "../api";
import { useAuth } from "../AuthContext";
export default function Doctor() {
  const { id } = useParams(); const nav = useNavigate(); const { user } = useAuth();
  const [d, setD] = useState(null); const [date, setDate] = useState(""); const [time, setTime] = useState(""); const [booked, setBooked] = useState([]); const [reason, setReason] = useState("");
  useEffect(() => { api.get(`/doctors/${id}`).then((r) => setD(r.data)); }, [id]);
  useEffect(() => { if (date) api.get(`/doctors/${id}/booked`, { params: { date } }).then((r) => setBooked(r.data)); }, [date, id]);
  if (!d) return <p className="wrap">Loading…</p>;
  const slots = []; for (let h = d.startHour; h < d.endHour; h++) slots.push(`${String(h).padStart(2, "0")}:00`, `${String(h).padStart(2, "0")}:30`);
  const ok = date && d.availableDays.includes(new Date(date + "T00:00").getDay());
  const book = async () => { try { await api.post("/appointments", { doctor: id, date, time, reason }); alert("Booked!"); nav("/dashboard"); } catch (e) { alert(e.response?.data?.message); } };
  return <div className="wrap"><div className="card"><h1>{d.name}</h1><p>{d.specialization} · {d.department?.name} · {d.experienceYears} yrs · ₹{d.fee}</p><p>{d.bio}</p><p>Available: {d.availableDays.map((n) => DAYS[n]).join(", ")}</p></div>
    <div className="card" style={{ marginTop: 14 }}><h2>Book</h2>
      <input type="date" min={new Date().toISOString().slice(0, 10)} value={date} onChange={(e) => { setDate(e.target.value); setTime(""); }} />
      {date && !ok && <p>Doctor not available on this day.</p>}
      {ok && <div className="slots">{slots.map((t) => <button key={t} disabled={booked.includes(t)} className={time === t ? "sel" : ""} onClick={() => setTime(t)}>{t}</button>)}</div>}
      {time && <><textarea placeholder="Reason" value={reason} onChange={(e) => setReason(e.target.value)} />{user?.role === "patient" ? <button onClick={book}>Confirm {date} {time}</button> : <p>Sign in as a patient to book.</p>}</>}
    </div></div>;
}
