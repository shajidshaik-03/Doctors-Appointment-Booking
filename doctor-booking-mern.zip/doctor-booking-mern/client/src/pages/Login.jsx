import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import { useAuth } from "../AuthContext";
export default function Login() {
  const [mode, setMode] = useState("login"); const [f, setF] = useState({ name: "", email: "", password: "" });
  const { login } = useAuth(); const nav = useNavigate();
  const submit = async (e) => { e.preventDefault(); try { const r = await api.post(`/auth/${mode}`, f); login(r.data); nav("/dashboard"); } catch (err) { alert(err.response?.data?.message); } };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return <div className="wrap" style={{ maxWidth: 400 }}><form className="card" onSubmit={submit}><h2>{mode === "login" ? "Sign in" : "Register"}</h2>
    {mode === "register" && <input placeholder="Full name" value={f.name} onChange={set("name")} />}
    <input type="email" placeholder="Email" value={f.email} onChange={set("email")} required /><input type="password" placeholder="Password" value={f.password} onChange={set("password")} required />
    <button>{mode === "login" ? "Sign in" : "Create account"}</button>
    <p><a href="#" onClick={() => setMode(mode === "login" ? "register" : "login")}>{mode === "login" ? "Create an account" : "Have an account? Sign in"}</a></p></form></div>;
}
