import { useEffect, useState } from "react";
import api, { DAYS } from "../api";
import { useAuth } from "../AuthContext";
export default function Dashboard() {
  const { user } = useAuth(); const [tab, setTab] = useState("appts");
  if (!user) return <p className="wrap">Loading…</p>;
  return <div className="wrap"><h1>{user.role} dashboard</h1>
    {user.role === "admin" && <p>{["appts", "doctors", "depts"].map((t) => <button key={t} className={tab === t ? "" : "ghost"} onClick={() => setTab(t)} style={{ marginRight: 6 }}>{t}</button>)}</p>}
    {tab === "appts" ? <Appts role={user.role} /> : tab === "doctors" ? <Doctors /> : <Depts />}</div>;
}
function Appts({ role }) {
  const [list, setList] = useState([]); const load = () => api.get("/appointments").then((r) => setList(r.data)); useEffect(() => { load(); }, []);
  const st = async (id, status) => { await api.put(`/appointments/${id}/status`, { status }); load(); };
  const del = async (id) => { await api.delete(`/appointments/${id}`); load(); };
  return <table className="card"><thead><tr><th>Date</th><th>Time</th><th>Doctor</th><th>Patient</th><th>Status</th><th></th></tr></thead><tbody>
    {list.map((a) => <tr key={a._id}><td>{a.date}</td><td>{a.time}</td><td>{a.doctor?.name}</td><td>{a.patient?.name}</td><td>{a.status}</td><td>
      {role !== "patient" && a.status === "pending" && <button onClick={() => st(a._id, "confirmed")}>Confirm</button>}
      {role !== "patient" && a.status === "confirmed" && <button onClick={() => st(a._id, "completed")}>Complete</button>}
      {["pending", "confirmed"].includes(a.status) && <button className="ghost" onClick={() => st(a._id, "cancelled")}>Cancel</button>}
      {role === "admin" && <button className="ghost" onClick={() => del(a._id)}>Delete</button>}</td></tr>)}</tbody></table>;
}
const blank = { name: "", email: "", department: "", specialization: "", experienceYears: 0, fee: 500, bio: "", availableDays: [1, 2, 3, 4, 5], startHour: 9, endHour: 17 };
function Doctors() {
  const [list, setList] = useState([]); const [depts, setDepts] = useState([]); const [f, setF] = useState(null);
  const load = () => api.get("/doctors").then((r) => setList(r.data));
  useEffect(() => { load(); api.get("/departments").then((r) => setDepts(r.data)); }, []);
  const save = async () => { const body = { ...f, department: f.department || undefined }; f._id ? await api.put(`/doctors/${f._id}`, body) : await api.post("/doctors", body); setF(null); load(); };
  const set = (k, num) => (e) => setF({ ...f, [k]: num ? +e.target.value : e.target.value });
  return <><button onClick={() => setF(blank)}>+ Add doctor</button>
    {f && <div className="card"><input placeholder="Name" value={f.name} onChange={set("name")} /><input placeholder="Login email" value={f.email} onChange={set("email")} />
      <select value={f.department?._id ?? f.department} onChange={set("department")}><option value="">Department</option>{depts.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select>
      <input placeholder="Specialization" value={f.specialization} onChange={set("specialization")} /><input type="number" placeholder="Fee" value={f.fee} onChange={set("fee", 1)} />
      <input type="number" placeholder="Experience" value={f.experienceYears} onChange={set("experienceYears", 1)} />
      <p>{DAYS.map((d, i) => <label key={d} style={{ marginRight: 8 }}><input type="checkbox" style={{ width: "auto" }} checked={f.availableDays.includes(i)} onChange={() => setF({ ...f, availableDays: f.availableDays.includes(i) ? f.availableDays.filter((x) => x !== i) : [...f.availableDays, i] })} />{d}</label>)}</p>
      <button onClick={save}>Save</button> <button className="ghost" onClick={() => setF(null)}>Cancel</button></div>}
    <table className="card"><tbody>{list.map((d) => <tr key={d._id}><td>{d.name}</td><td>{d.department?.name}</td><td>₹{d.fee}</td><td><button className="ghost" onClick={() => setF({ ...d, department: d.department?._id ?? "" })}>Edit</button> <button className="ghost" onClick={async () => { await api.delete(`/doctors/${d._id}`); load(); }}>Delete</button></td></tr>)}</tbody></table></>;
}
function Depts() {
  const [list, setList] = useState([]); const [name, setName] = useState("");
  const load = () => api.get("/departments").then((r) => setList(r.data)); useEffect(() => { load(); }, []);
  return <><input placeholder="New department" value={name} onChange={(e) => setName(e.target.value)} /><button onClick={async () => { await api.post("/departments", { name }); setName(""); load(); }}>Add</button>
    <ul>{list.map((d) => <li key={d._id}>{d.name} <button className="ghost" onClick={async () => { const n = prompt("Rename", d.name); if (n) { await api.put(`/departments/${d._id}`, { name: n }); load(); } }}>Edit</button> <button className="ghost" onClick={async () => { await api.delete(`/departments/${d._id}`); load(); }}>Delete</button></li>)}</ul></>;
}
