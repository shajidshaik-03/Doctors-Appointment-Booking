# CareSlot — Doctor Appointment Booking (MERN)
Roles: admin, doctor, patient (JWT auth). First registered user becomes admin.
## Run
1. Start MongoDB locally (mongodb://127.0.0.1:27017).
2. `cd server && npm install && cp .env.example .env && npm run seed && npm start` (port 5000)
3. `cd client && npm install && npm run dev` (port 5173)
## REST API
POST /api/auth/register | POST /api/auth/login | GET /api/auth/me
GET/POST/PUT/DELETE /api/departments[/:id]  (write: admin)
GET /api/doctors?q=&department= | GET /api/doctors/:id | POST/PUT/DELETE (admin)
GET /api/doctors/:id/booked?date=YYYY-MM-DD
GET /api/appointments (own / doctor's / all for admin) | POST (patient) | PUT /:id/status | DELETE /:id (admin)
